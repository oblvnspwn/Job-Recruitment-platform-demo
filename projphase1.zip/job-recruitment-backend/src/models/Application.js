const mongoose = require('mongoose');

const applicationSchema = new mongoose.Schema({
    job: {
        type: mongoose.Schema.ObjectId,
        ref: 'Job',
        required: true,
    },
    applicant: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
        required: true,
    },
    resumeUrl: {
        type: String,
        required: [true, 'Please upload a resume'],
    },
    coverLetter: {
        type: String,
    },
    status: {
        type: String,
        enum: ['applied', 'reviewed', 'interview', 'hired', 'rejected'],
        default: 'applied',
    },
    appliedAt: {
        type: Date,
        default: Date.now,
    },
});

// Prevent user from applying to the same job twice
applicationSchema.index({ job: 1, applicant: 1 }, { unique: true });

module.exports = mongoose.model('Application', applicationSchema);
