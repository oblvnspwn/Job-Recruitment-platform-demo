const mongoose = require('mongoose');

const jobSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, 'Please add a job title'],
        trim: true,
        maxlength: [100, 'Job title can not be more than 100 characters'],
    },
    description: {
        type: String,
        required: [true, 'Please add a description'],
    },
    requirements: {
        type: String,
        required: [true, 'Please add requirements'],
    },
    location: {
        type: String,
        required: [true, 'Please add a location'],
    },
    industry: {
        type: String,
        required: [true, 'Please add an industry'],
    },
    salary: {
        type: Number,
        required: [true, 'Please add a salary'],
    },
    employer: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
        required: true,
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model('Job', jobSchema);
