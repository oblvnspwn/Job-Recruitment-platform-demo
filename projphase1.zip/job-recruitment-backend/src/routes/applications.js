const express = require('express');
const {
    applyForJob,
    getJobApplications,
    getMyApplications,
} = require('../controllers/applicationController');

const { protect, authorize } = require('../middleware/auth');
const upload = require('../config/cloudinary');

const router = express.Router();

router.post('/:jobId', protect, authorize('job_seeker'), upload.single('resume'), applyForJob);
router.get('/job/:jobId', protect, authorize('employer', 'admin'), getJobApplications);
router.get('/me', protect, authorize('job_seeker'), getMyApplications);

module.exports = router;
