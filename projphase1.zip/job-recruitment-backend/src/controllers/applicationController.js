const Application = require('../models/Application');
const Job = require('../models/Job');

// @desc    Apply for a job
// @route   POST /api/applications/:jobId
// @access  Private (Job Seeker)
exports.applyForJob = async (req, res) => {
    try {
        const job = await Job.findById(req.params.jobId);

        if (!job) {
            return res.status(404).json({ success: false, error: 'Job not found' });
        }

        // Check if user already applied
        const existingApplication = await Application.findOne({
            job: req.params.jobId,
            applicant: req.user.id,
        });

        if (existingApplication) {
            return res.status(400).json({ success: false, error: 'You have already applied for this job' });
        }

        // Check if resume file is present
        if (!req.file) {
            return res.status(400).json({ success: false, error: 'Please upload a resume' });
        }

        const application = await Application.create({
            job: req.params.jobId,
            applicant: req.user.id,
            resumeUrl: req.file.path,
            coverLetter: req.body.coverLetter,
        });

        res.status(201).json({
            success: true,
            data: application,
        });
    } catch (error) {
        res.status(400).json({ success: false, error: error.message });
    }
};

// @desc    Get applications for a job (Employer)
// @route   GET /api/applications/job/:jobId
// @access  Private (Employer)
exports.getJobApplications = async (req, res) => {
    try {
        const job = await Job.findById(req.params.jobId);

        if (!job) {
            return res.status(404).json({ success: false, error: 'Job not found' });
        }

        // Make sure user is job owner
        if (job.employer.toString() !== req.user.id && req.user.role !== 'admin') {
            return res.status(401).json({
                success: false,
                error: `User ${req.user.id} is not authorized to view applications for this job`,
            });
        }

        const applications = await Application.find({ job: req.params.jobId }).populate({
            path: 'applicant',
            select: 'name email',
        });

        res.status(200).json({
            success: true,
            count: applications.length,
            data: applications,
        });
    } catch (error) {
        res.status(400).json({ success: false, error: error.message });
    }
};

// @desc    Get my applications (Job Seeker)
// @route   GET /api/applications/me
// @access  Private (Job Seeker)
exports.getMyApplications = async (req, res) => {
    try {
        const applications = await Application.find({ applicant: req.user.id }).populate({
            path: 'job',
            select: 'title company location',
        });

        res.status(200).json({
            success: true,
            count: applications.length,
            data: applications,
        });
    } catch (error) {
        res.status(400).json({ success: false, error: error.message });
    }
};
