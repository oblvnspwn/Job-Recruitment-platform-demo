const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('./models/User');
const Job = require('./models/Job');
const connectDB = require('./config/db');

dotenv.config();

connectDB();

const importData = async () => {
    try {
        // Clear existing data
        await User.deleteMany();
        await Job.deleteMany();

        // Create Employer
        const employer = await User.create({
            name: 'Tech Corp',
            email: 'hr@techcorp.com',
            password: 'password123',
            role: 'employer',
        });

        // Create Jobs
        const jobs = [
            {
                title: 'Senior Node.js Developer',
                description: 'We are looking for an experienced backend developer to join our team.',
                requirements: 'Node.js, MongoDB, Express, AWS',
                location: 'Remote',
                industry: 'Technology',
                salary: 120000,
                employer: employer._id,
            },
            {
                title: 'Frontend React Engineer',
                description: 'Join us to build beautiful user interfaces.',
                requirements: 'React, Redux, CSS, HTML',
                location: 'New York, NY',
                industry: 'Technology',
                salary: 110000,
                employer: employer._id,
            },
            {
                title: 'Product Manager',
                description: 'Lead our product team to success.',
                requirements: 'Agile, Scrum, Product Lifecycle',
                location: 'San Francisco, CA',
                industry: 'Business',
                salary: 140000,
                employer: employer._id,
            },
        ];

        await Job.insertMany(jobs);

        console.log('Data Imported!');
        process.exit();
    } catch (error) {
        console.error(`${error}`);
        process.exit(1);
    }
};

importData();
